'use strict';
const test=require('node:test'),assert=require('node:assert'),S=require('../www/status.js');
const ASSESS=['exam'],WORK=['assignment','project','task',undefined,null,''];
const BANNED=/\b(due|overdue|late|missed|failed)\b/i;
test('only kind "exam" (tests, quizzes, exams, midterms, finals) is an assessment',()=>{
 assert.ok(S.isAssessment({kind:'exam'}));for(const k of WORK)assert.ok(!S.isAssessment({kind:k}),String(k));
 assert.ok(!S.isAssessment(null)&&!S.isAssessment(undefined))});
for(const k of ASSESS)test('assessment wording: '+k,()=>{const t={kind:k};
 assert.strictEqual(S.label(-3,t),'Past date');assert.strictEqual(S.label(0,t),'Today');assert.strictEqual(S.label(1,t),'Tomorrow');
 assert.strictEqual(S.label(3,t),null,'future dates beyond tomorrow still show the calendar date');
 assert.strictEqual(S.status(-3,t),'Past date');assert.strictEqual(S.status(0,t),'Today');assert.strictEqual(S.status(1,t),'Tomorrow');assert.strictEqual(S.status(3,t),'In 3 days');
 assert.strictEqual(S.why(3,t),'it is in 3 days');assert.strictEqual(S.why(1,t),'it is tomorrow');assert.strictEqual(S.why(0,t),'it is today');assert.strictEqual(S.why(-2,t),'its date has passed');
 for(const n of [-30,-1,0,1,2,3,10]){for(const f of [S.label,S.status,S.why]){const v=f(n,t);if(v)assert.ok(!BANNED.test(v),`"${v}" must not imply something was due, late or missed`)}}});
for(const k of WORK)test('assignment wording keeps due/overdue: '+k,()=>{const t={kind:k};
 assert.strictEqual(S.label(-2,t),'2d overdue');assert.strictEqual(S.label(0,t),'Today');assert.strictEqual(S.label(1,t),'Tomorrow');assert.strictEqual(S.label(3,t),null);
 assert.strictEqual(S.status(-2,t),'Overdue');assert.strictEqual(S.status(0,t),'Due today');assert.strictEqual(S.status(1,t),'Due tomorrow');assert.strictEqual(S.status(3,t),'Due in 3 days');
 assert.strictEqual(S.why(3,t),'it is due in 3 days');assert.strictEqual(S.why(1,t),'it is due tomorrow');assert.strictEqual(S.why(0,t),'it is due today');assert.strictEqual(S.why(-2,t),'it is overdue')});
test('a plain date with no task (events, class end dates) is never called overdue',()=>{assert.strictEqual(S.label(-5),'Past date');assert.strictEqual(S.label(-5,null),'Past date')});

test('past tests (and study steps for one) are not suggested; everything else still is',()=>{
 const exam={kind:'exam'},work={kind:'project'},step={kind:'task'};
 assert.ok(S.pastAssessment(exam,null,-1),'past test is left out');
 assert.ok(S.pastAssessment(step,exam,-3),'a step of a past test is left out');
 assert.ok(!S.pastAssessment(exam,null,0),'a test today is still suggested');
 assert.ok(!S.pastAssessment(exam,null,1)&&!S.pastAssessment(exam,null,5),'upcoming tests are still suggested');
 assert.ok(!S.pastAssessment(work,null,-4),'an overdue assignment is still suggested');
 assert.ok(!S.pastAssessment(step,work,-4),'a step of an overdue assignment is still suggested');
 assert.ok(!S.pastAssessment(step,null,-2),'an overdue plain task is still suggested')});
