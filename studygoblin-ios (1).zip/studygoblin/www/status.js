/* Date-status wording. Assessments (kind 'exam': tests, quizzes, exams, midterms, finals) are not submitted, so they never
   say "due" or "overdue"; a past one is just a "Past date". Work that is handed in keeps "Due in..." and "Overdue". */
(function(root){
'use strict';
const isAssessment=t=>!!t&&t.kind==='exam';
// Short label for cards. n = days from today (negative = past). null means "show the calendar date instead".
function label(n,t){return n==0?'Today':n==1?'Tomorrow':n<0?(t&&!isAssessment(t)?Math.abs(n)+'d overdue':'Past date'):null}
// Full status phrase.
function status(n,t){if(isAssessment(t))return n<0?'Past date':n==0?'Today':n==1?'Tomorrow':'In '+n+' days';
 return n<0?'Overdue':n==0?'Due today':n==1?'Due tomorrow':'Due in '+n+' days'}
// Reason phrase used by Goblin's pick ("Because it is ...").
function why(n,t){if(isAssessment(t))return n<0?'its date has passed':n==0?'it is today':n==1?'it is tomorrow':'it is in '+n+' days';
 return n<0?'it is overdue':n==0?'it is due today':n==1?'it is due tomorrow':'it is due in '+n+' days'}
// A test whose date has passed (or a study step belonging to one) is not suggested as the next thing to do.
function pastAssessment(t,parent,n){return n<0&&(isAssessment(t)||isAssessment(parent))}
const api={isAssessment,label,status,why,pastAssessment};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.SGS=api;
})(typeof window!=='undefined'?window:globalThis);
